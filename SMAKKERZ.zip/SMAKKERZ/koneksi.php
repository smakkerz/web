<?php
error_reporting(E_ALL ^ E_DEPRECATED);
class database { 
	private $dbHost="localhost";
	private $dbUser="root";
	private $dbPass="";
	private $dbName="perpus";
// fungsi untuk melakukan koneksi ke database mysql
function koneksi_buka() {
	mysql_connect($this->dbHost, $this->dbUser, $this->dbPass);
	mysql_select_db($this->dbName) or die (" ");
	}
}
	class user { 
		function ceklogin($username, $password) {
		$password = md5($password);
		$result = mysql_query("SELECT * FROM admin WHERE username='$username' 
								AND password='$password'");
		$userdata = mysql_fetch_array($result);
		$no = mysql_num_rows($result);
		if ($no == 1) {
			$_SESSION['masuk'] = TRUE;
			$_SESSION['id'] = $userdata['id'];
			return TRUE;
		} else {
			return FALSE;
			}
		}
		function sesi() {
		return $_SESSION['masuk'];
		}
		function ceklogout() {
		$_session['masuk'] = FALSE;
		session_destroy();
		}
	}
?>
