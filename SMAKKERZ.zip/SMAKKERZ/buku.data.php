<?php
error_reporting(E_ALL ^ E_DEPRECATED);
// panggil berkas koneksi.php
require 'koneksi.php';

// buat koneksi ke database mysql
$db = new database();
$db->koneksi_buka();

?>
<div class="container">
	<div class="table-responsive">
		<table class="table table-condensed table-bordered table-hover" >
			<thead>
				<tr>
					<th>No</th>
					<th>Penerbit</th>
					<th>Penyusun</th>
					<th>Judul</th>
					<th>Kategori</th>
					<th>Stock</th>
					<th>Harga</th>
					<th>Deskripsi</th>
					<th>Status</th>
				</tr>
			</thead>
			<tbody>
	<?php 
		$i = 1;
		$query = mysql_query("SELECT * FROM buku");
		
		// tampilkan data Buku selama masih ada
		while($data = mysql_fetch_array($query)) {
			if($data['id']==1) {
				$id = "Masih Ada";
			} else {
				$id = "Kosong";
			}
	?>
	<tr class="info">
		<td><?php echo $i ?></td>
		<td><?php echo $data['penerbit'] ?></td>
		<td><?php echo $data['penyusun'] ?></td>
		<td><?php echo $data['judul'] ?></td>
		<td><?php echo $data['kategori'] ?></td>
		<td><?php echo $data['stock']; ?></td>
		<td><?php echo "Rp. ";
			echo $data['harga'] ?> </td>
		<td>
			<button type="button" class="btn btn-success" title="Deskripsi Buku <?php echo $data['judul'] ?>" 
			data-container="body" data-toggle="popover" data-placement="bottom" 
			data-content="<?php echo $data['sekilas'] ?>"> Detail </button>
				<script>$(function () { $("[data-toggle='popover']").popover(); }); </script>
		</td>
		<td>
			<a href="#dialog-buku" id="<?php echo $data['id'] ?>" class="ubah" data-toggle="modal">
				<i class="icon-edit"></i>
			</a>
			<a href="#" id="<?php echo $data['id'] ?>" class="hapus">
				<i class="icon-trash"></i>
			</a>
		</td>
	</tr>
	<?php
		$i++;
		}
	?>
			</tbody>
		</table>
	</div>
</div>

