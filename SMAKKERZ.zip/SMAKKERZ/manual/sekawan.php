<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>4-Login</title>
	<link rel="icon" href="../4.jpg" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="favicon.png"/>
	<link href="../css/font-awesome.min.css" rel="stylesheet">
	<link href="../css/main.css" rel="stylesheet">
	<link href="../css/responsive.css" rel="stylesheet">
	<link href="../css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link href="../css/sekawan.css" rel="stylesheet">

	<script type="text/javascript" src="../js/jquery.min.js"></script>
	<script type="text/javascript" src="../js/bootstrap.min.js"></script>
</head>
<body data-spy="scroll">
          <nav class="navbar navbar-inverse" role="navigation"> 
	<div class="Alert alert-info"> 
		<ul class="pager"> <h4>
			<li class="info"><a href="#sekawan">Sekawan</a></li>
			<li class="active"><a href="#Penulis">About Me</a></li>
			<li class="active"><a href="index.php/../.."><span class="glyphicon glyphicon-home">>Menuju Aplikasi</span></a></li> 
			</h4>
		</ul> 
			</li> 
		</ul> 
	</div> 
		</nav>
   <div class="container">
		<div class="section"> 
		<h4 id="sekawan"><p class="text-info">Sekawan</p></h4>
			<div class="panel panel-primary"> 
					<div class="panel-heading"> 
						<h3 class="panel-title">INFORMASI</h3> 
					</div> 
				<div class="panel-body">Sistem Aplikasi persediaan Buku Online bisa difungsikan untuk menjadi Cpanel dalam persediaan buku
				dimana aplikasi ini membantu dalam melakukan penginputan persediaan buku. Dalam aplikasi ini masih jauh dari harapan penulis
				Harapan penulis sistem ini bisa digunakan untuk transaksi buku, stock buku, dan halaman user.
				<p >- Transaksi buku diperlukan untuk penggunaan aplikasi sebagai pengganti peminjaman/pembelian buku</p>
				<p >- Stock buku digunakan untuk mengetahui jumlah buku yang ada serta kapan jumlah buku akan dikembalikan(peminjaman)<br>
					atau untuk melakukan pengisian buku yang habis(pembelian)</p>
				<p> - Halaman User digunakan untuk memberikan kemudahan bagi pelanggan untuk melihat katalog buku/ rak-rak buku yang ada di sistem tersebut.</p>
				Tujuannya Sistem ini bisa diperlukan untuk bisnis "toko buku", edukasi "perpustakaan" atau bisa juga untuk pergudangan,dll.
				Untuk versi Beta 1.61 bisa digunakan sebagai bahan pembelajaran yang ingin mempelajari tentang membangun sebuah web, dimana
				pada website ini cukup lengkap untuk bahan pembelajaran.<br>
				<p class="text-danger">Kenapa tidak membuat sesuai harapan penulis ??<br>
					Dikarenakan waktu untuk membuatnya cukup singkat dan ilmu penulis yang masih dangkal maka penulis membuat menjadi beberapa tahap
					dan Mudah-mudahan untuk versi berikutnya lebih bermanfaat dan lebih lengkap lagi dari ini.</p>
				</div> 
			</div> 
		</div>
		<div class="section"> 
			<h4 id="Penulis"><p class="text-warning">Tentang Penulis</p></h4>
				<div class="panel panel-primary"> 
					<div class="panel-heading"> 
						<h3 class="panel-title">Tentang Penulis</h3> 
					</div> 
		<div class="container">
					<div class="panel-body">
						<div id="slide-promo" class="carousel slide">
<!-- Indikator slide -->
					<ol class="carousel-indicators">
						<li data-target="#slide-promo" data-slide-to="0" class="active"> </li>
						<li data-target="#slide-promo" data-slide-to="1"></li>
						<li data-target="#slide-promo" data-slide-to="2"></li>
						<li data-target="#slide-promo" data-slide-to="3"></li>
					</ol>
<!-- gambar yang di-slide-show -->
					<div class="carousel-inner">
<!-- gambar ke-1 -->
						<div class="item active">
							<img src="galeri/dp4.jpg" class="center" alt="buku">
								<div class="carousel-caption">
									<h3>Saya Yusuf Adhi Tomo</h3>
									Gemar Berolahraga, Touring,dan Belajar dunia IT<br>(Python,open source, website, web service, dan mikrokontroller)
									<span class="icon-thumbs-up"></span>
								</div>
						</div>
<!-- gambar ke-2 -->
						<div class="item">
							<img src="galeri/dp.jpg" class="center" alt="sekawan buku">
								<div class="carousel-caption">
									<h3>Saya Yusuf Adhi Tomo</h3>
									Inilah saya orang yang bodoh tapi tetap berusaha untuk bermanfaat, </br>
									lebih baik bodoh bermanfaat daripada pintar membahayakan
								</div>
						</div>
<!-- gambar ke-3 -->	
						<div class="item">
							<img src="galeri/dpp.jpg" class="center" alt="sekawan.com">
								<div class="carousel-caption">
									<h3>Saya Yusuf Adhi Tomo</h3>
									<p class="lead">Belajar juga tentang NOSQL, JAVA for Android, 
									<br>Dan masih banyak yang perlu dipelajari</p>
							</div>
						</div>
						<div class="item">
							<img src="galeri/dpku.jpg" class="center" alt="sekawan">
								<div class="carousel-caption">
									<h3>Saya Yusuf Adhi Tomo</h3>
									<p class="lead">Saya saat ini tinggal di Semarang</p>
								</div>
						</div>
					</div>
<!-- Controls -->
				<a class="left carousel-control" href="#slide-promo" data-slide="prev">
					<span class="icon-prev"></span>
				</a>
				<a class="right carousel-control" href="#slide-promo" data-slide="next">
					<span class="icon-next"></span>
				</a>
			</div>
		</div>
		<h3>PENDIDIKAN</h3> <p> MI FUTTUHIYYAH SEMARANG</p>
				<p>SMP AT THOHIRIYYAH SEMARANG</p><p>SMK Negeri 1 SEMARANG Teknik Audio-Video</p><p><small>Sedang menempuh</small> 
				S1 - Teknik Informatika Fakultas Teknologi Informasi dan Komunikasi UNIVERSITAS SEMARANG [USM] </p>
				<h3>KEGEMARAN</h3>
				<p>Olahraga</p><p>Touring</p><p>Dan Belajar</p>
				<h3>KEGEMARAN DALAM BIDANG IT</h3>
				<p>Python, open source, website, Visual Basic, .NET, C++, Algoritma, JAVA OOP, BASHELL, Sistem Digital</p>
				<p>Sedang mempelajari NOSQL, Web service, Perl, JAVA for Android, dan masih banyak lainnya</p>
					</div> 
				</div> 
			</div>
		</div>
	</div>
<div class="footer-bottom">
	<div class="container">
		<div class="col-md-10">
			<p class="pull-left">Versi Beta 1.61</p>
			<p class="pull-right">&copy; Yusuf Adhi Tomo &middot; 2016 || E-mail : yusufadhi77@gmail.com / yusufadhi7@ymail.com<span></span></p>
		</div>
	</div>
</div>
 </body>
 </html>