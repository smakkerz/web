<?php
error_reporting(0);
error_reporting(E_ALL ^ E_DEPRECATED);
session_start();
require 'koneksi.php';

$db = new database();
$db->koneksi_buka();

$user = new user();

function anti_injection($data){
$filter=mysql_real_escape_string(stripslashes(strip_tags(htmlspecialchars($data,ENT_QUOTES))));
return $filter;
}
if($_SERVER["REQUEST_METHOD"] == "POST") {
	$masuk=$user->ceklogin($_POST['username'], $_POST['password']);
	if($masuk) {
		header("location:indo.php?page=home");
	} else { 
?>
	<script language="javascript">
	document.location="index.php?gagal";
	alert ("Gagal Login yaa???");
	</script>
<?php	
	}
}

	?>
<!DOCTYPE html>
<head>
	<meta charset="utf-8">
	<title>4-Login</title>
	<link rel="icon" href="4.jpg" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">
	
	<link rel="shortcut icon" href="favicon.png"/>
	<link href="css/font-awesome.min.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	<link href="css/responsive.css" rel="stylesheet">
	<link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
	<link href="css/bootstrap.css" rel="stylesheet">

	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>
<body bakground>
<div id="slide-promo" class="carousel slide">
<!-- Indikator slide -->
		<ol class="carousel-indicators">
			<li data-target="#slide-promo" data-slide-to="0" class="active"> </li>
			<li data-target="#slide-promo" data-slide-to="1"></li>
			<li data-target="#slide-promo" data-slide-to="2"></li>
		</ol>
<!-- gambar yang di-slide-show -->
<div class="carousel-inner">
<!-- gambar ke-1 -->
	<div class="item active">
		<img src="img/buk.jpg" alt="buku">
		<div class="carousel-caption">
			<h3>Daftar Buku Yang ada di Sekawan</h3>
			<p class="lead">Cukup menarik belajar PHP OOP & MYSQLi
			<span class="icon-thumbs-up"></span></p>
		</div>
	</div>
<!-- gambar ke-2 -->
	<div class="item">
		<img src="img/800.jpg" alt="sekawan buku">
		<div class="carousel-caption">
			<h3>Daftar Buku Yang ada di Sekawan</h3>
			<p class="lead">Hidup pasti INDAH pada akhirnya</p>
		</div>
	</div>
<!-- gambar ke-3 -->	
	<div class="item">
		<img src="img/900.png" alt="sekawan.com">
		<div class="carousel-caption">
			<h3>Sekawan Buku Online</h3>
			<p class="lead">Kapanpun siap</p>
			</div>
		</div>
	</div>
<!-- Controls -->
<a class="left carousel-control" href="#slide-promo" data-slide="prev">
	<span class="icon-prev"></span>
</a>
<a class="right carousel-control" href="#slide-promo" data-slide="next">
	<span class="icon-next"></span>
</a>
</div><!-- /slide-promo -->
<div class="row">
		<div class="col-md-9">
			<h3><marquee>
			Selamat Datang Di Sekawan &middot; Pendataan Buku
			</marquee></h3>
		</div>
	</div>
	<div class="container">
	<div class="rows">
		<div class="col-sm-5 col-sm-offset-1">
			<div class="login-form">
			<h3>LOGIN ADMINISTRATOR</h3>
				<form class="form-horizontal" name="masuk" role="form" method="post">
					<input type="text" class="form-control" name="username" placeholder="Username..." required />
					<input type="password" class="form-control" name="password" placeholder="Password..." required />
					<span>
					<input type="checkbox"> Tetap Masuk
					</span>
					<button type="submit" class="btn btn-primary" ><span class="icon-book"></span>Masuk</button>
				</form>
			</div>
		</div>
			<div class="col-sm-5">
				<?php require 'isi.php'; ?>
			</div>
	</div>
	</div>
<hr>
<footer id="footer">
<div class="container">
	<div class="footer-top">
		<div class="form-group">
			<div class="col-sm-4 col-sm-offset-1" style="background-color: #ffffee;">
				<p><center>Desaigned by &middot; SMAKKERZ </center></p>
				<ul class="nav nav-pills nav-stacked">
					<li class="active">
					<a href="manual/sekawan.php"><i class="icon-user"></i>INFO</a></li>
					<li><a href="manual/sekawan.php">E-mail : yusufadhi77@gmail.com OR yusufadhi7@ymail.com</a></li>
					<li><a href="manual/sekawan.php">Contact Person(WA) : 089 66 44 51 557</a></li>
					<li><a href="manual/sekawan.php">Line : _you7</a></li>
					<li><a href="manual/sekawan.php">Pin BBM : 54087411</a></li>
				</ul>
			</div>
		</div>
		<div class="col-sm-4">
			<div class="signup-form"><!--sign up form-->
				<h2>SOCIALITE</h2>
					<ul class="icons">
						<li><a href="#" class="icon circle fa fa-twitter"><span class="label">Twitter</span></a></li>
						<li><a href="#" class="icon circle fa-facebook"><span class="label">Facebook</span></a></li>
						<li><a href="#" class="icon circle fa-google-plus"><span class="label">Google+</span></a></li>
						<li><a href="#" class="icon circle fa-github"><span class="label">Github</span></a></li>
						<li><a href="#" class="icon circle fa-dribbble"><span class="label">Dribbble</span></a></li>
					</ul>
			</div><!--/sign up form-->
			<p class="text-success">"Pendosa berhak memiliki masa depan"</p>
			<p class="text-info">"Menerima musibah itu sulit, sebenarnya Tuhan sedang memperhatikan hamba-Nya"</p>
			<p class="text-danger">""Semakin tinggi Prinsip Hidup semakin hebat pula cobaan hidup.""</p>
		</div>
	</div>
</div>
<div class="footer-bottom">
	<div class="container">
		<div class="col-md-10">
			<p class="pull-left">Versi Beta 1.61</p>
			<p class="pull-right">&copy; Yusuf Adhi Tomo &middot; 2016 || E-mail : yusufadhi77@gmail.com / yusufadhi7@ymail.com<span></span></p>
		</div>
	</div>
</div>
</footer>
</body>
	