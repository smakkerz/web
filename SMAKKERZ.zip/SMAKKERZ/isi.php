<nav class="navbar navbar-default" role="navigation"> 
	<div class="Alert alert-info"> 
		<ul class="pager"> 
			<li class="info"><a href="#sekawan">Sekawan</a></li>
			<li class="active"><a href="#admin">LOGIN</a></li> 
			<li class="dropdown"> <a href="manual/sekawan.php" class="dropdown-toggle" data-toggle="dropdown"> INFO
			<b class="caret"></b> </a> 
		<ul class="dropdown-menu"> 
			<li><a href="manual/sekawan.php">Manual</a></li> 
			<li><a href="manual/sekawan.php">MY BLOG</a></li> 
			<li><a href="manual/sekawan.php">WA : 089664451557</a></li> 
			<li class="divider"></li> 
			<li><a href="manual/sekawan.php">LIFE IS EASY,</a></li>
			<li class="divider"></li> 
			<li><a href="manual/sekawan.php">BUT it should not be underestimated</a></li> 
		</ul> 
			</li> 
		</ul> 
	</div> 
</nav>
<div class="section"> 
	<h4 id="sekawan">Sekawan<small></small></h4>
	<div class="panel panel-primary"> 
		<div class="panel-heading"> 
			<h3 class="panel-title">INFORMASI</h3> 
		</div> 
			<div class="panel-body">CPanel ini menggunakan PDO(PHP Data Object) & PHP native js(PHP yang value menggunakan jquery "AJAX"),
			Semoga berguna untuk lebih mengetahui tiap fungsi pada PDO sebagai landasan dasar PHP Framework.Untuk tahap selanjutnya 
			bagi yang ingin mengembangkan bisa berkolaborasi dengan saya.
			</div> 
	</div> 
</div>
		<div class="section"> 
			<h4 id="admin">LOGIN<small></small></h4>
			<a href="#" class="btn btn-primary btn-lg disabled" role="button">
				Username : admin ||| Password : admin</a></p> 
		</div>

</div>
