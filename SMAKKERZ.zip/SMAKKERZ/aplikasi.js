(function($) {
	// fungsi dijalankan setelah seluruh dokumen ditampilkan
	$(document).ready(function(e) {
		
		// deklarasikan variabel
		var id = 0;
		var main = "buku.data.php";
		
		// tampilkan data buku dari berkas buku.data.php 
		// ke dalam <div id="data-buku"></div>
		$("#data-buku").load(main);
		
		// ketika tombol ubah/tambah di tekan
		$('.ubah, .tambah').live("click", function(){
			
			var url = "buku.form.php";
			// ambil nilai id dari tombol ubah
			id = this.id;
			
			if(id != 0) {
				// ubah judul modal dialog
				$("#myModalLabel").html("Ubah Data Buku");
			} else {
				// saran dari mas hangs 
				$("#myModalLabel").html("Tambah Data Buku");
			}

			$.post(url, {id: id} ,function(data) {
				// tampilkan buku.form.php ke dalam <div class="modal-body"></div>
				$(".modal-body").html(data).show();
			});
		});
		
		// ketika tombol hapus ditekan
		$('.hapus').live("click", function(){
			var url = "buku.input.php";
			// ambil nilai id dari tombol hapus
			id = this.id;
			
			// tampilkan dialog konfirmasi
			var answer = confirm("Apakah anda ingin menghapus data Buku ini?");
			
			// ketika ditekan tombol ok
			if (answer) {
				// mengirimkan perintah penghapusan ke berkas transaksi.input.php
				$.post(url, {hapus: id} ,function() {
					// tampilkan data buku yang sudah di perbaharui
					// ke dalam <div id="data-buku"></div>
					$("#data-buku").load(main);
				});
			}
		});
		
		// ketika tombol simpan ditekan
		$("#simpan-buku").bind("click", function(event) {
			var url = "buku.input.php";

			// mengambil nilai dari inputbox, textbox dan select
			var v_penerbit = $('input:text[name=penerbit]').val();
			var v_penyusun = $('input:text[name=penyusun]').val();
			var v_judul = $('input:text[name=judul]').val();
			var v_kategori = $('select[name=kategori]').val();
			var v_stock = $('input:text[name=stock]').val();
			var v_harga = $('input:text[name=harga]').val();
			var v_sekilas = $('input:text[name=sekilas]').val();

			// mengirimkan data ke berkas transaksi.input.php untuk di proses
			$.post(url, {penerbit: v_penerbit, penyusun: v_penyusun, judul: v_judul, kategori: v_kategori, stock: v_stock, harga: v_harga, sekilas: v_sekilas, id: id} ,function() {
				// tampilkan data buku yang sudah di perbaharui
				// ke dalam <div id="data-buku"></div>
				$("#data-buku").load(main);

				// sembunyikan modal dialog
				$('#dialog-buku').modal('hide');
				
				// kembalikan judul modal dialog
				$("#myModalLabel").html("Tambah Data Buku");
			});
		});
	});
}) (jQuery);
