<?php
error_reporting(E_ALL ^ E_DEPRECATED);
require 'koneksi.php';

// buat koneksi ke database mysql
$db = new database();
$db->koneksi_buka();

// proses menghapus data Buku
if(isset($_POST['hapus'])) {
	mysql_query("DELETE FROM buku WHERE id=".$_POST['hapus']);
} else {
	// deklarasikan variabel
	$id	= $_POST['id'];
	$penerbit = $_POST['penerbit'];
	$penyusun = $_POST['penyusun'];
	$judul	= $_POST['judul'];
	$kategori = $_POST['kategori'];
	$stock = $_POST['stock'];
	$harga = $_POST['harga'];
	$sekilas = $_POST['sekilas'];
	
	// validasi agar tidak ada data yang kosong
	
	if($penerbit!="" && $penyusun!="" && $judul!="") {
		// proses tambah data Buku
		if($id == 0) {
			mysql_query("INSERT INTO buku VALUES('','$penerbit','$penyusun','$judul','$kategori','$stock','$harga','$sekilas')");
		// proses ubah data Buku
		} else {
			mysql_query("UPDATE buku SET 
			penerbit = '$penerbit',
			penyusun = '$penyusun',
			judul = '$judul',
			kategori = '$kategori',
			stock = '$stock',
			harga = '$harga',
			sekilas = '$sekilas'
			WHERE id = $id
			");
		}
	}
}

// tutup koneksi ke database mysql
koneksi_tutup();

?>
