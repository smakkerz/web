<?php 
error_reporting(E_ALL ^ E_DEPRECATED);
// memanggil berkas koneksi.php
session_start();
require 'koneksi.php'; 

$db = new database();
$db->koneksi_buka();

$user = new user();
$iduser = $_SESSION['id'];
	
if (!$user->sesi()) {
	header("location:index.php");
}
if ($_GET['page'] == 'out') {
	$user->ceklogout();
	header("location:index.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>4-Buku</title>
	<link rel="icon" href="4.jpg" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="">
	<meta name="author" content="">

	<link rel="shortcut icon" href="favicon.png"/>
	<link href="css/bootstrap1.min.css" rel="stylesheet" media="screen">
	<link href="css/responsive.css" rel="stylesheet">
	<link href="css/main.css" rel="stylesheet">
	
	<script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
</head>

<body>
<div class="navbar navbar-static-top">
	<div class="navbar-inner">
		<div class="container">
			<div class="row">
				<div class="col-sm-3 col-md-6 col-lg-4">
					<a class="brand" href="?page=home">
						<p class="tooltip-options" ><i class="icon-refresh"></i> 
							<img src="4.jpg" class="img-circle" width="45px" height="45px" class="tooltip-toggle" data-toggle="tooltip" 
							title="Sebuah Aplikasi/Sistem pendataan Buku yang bisa digunakan untuk berbasis Online/Offline">
							Toko Buku KITA(4 Buku)</a>
						</p>
					<script> 
						$(function () { $('.tooltip-destroy').tooltip('destroy');});
						$(function () { $("[data-toggle='tooltip']").tooltip(); }); 
						$(function () { $(".tooltip-options a").tooltip({html : true });
					</script>
				<div class="col-sm-9 col-md-6 col-lg-8">
					
					<div class="text-right">
					<?php require 'logout.php'; ?>
					</div>
				</div>
			</div>
		</div>	
	</div>
</div>
<div class="container">
	<div class="row">
		<h3><p class="tooltip-options" >
				<img src="4.jpg" class="img-circle" width="55px" height="55px" class="tooltip-toggle" data-toggle="tooltip" 
				title="Sebuah Aplikasi/Sistem pendataan Buku yang bisa digunakan untuk berbasis Online/Offline">
				Data Buku
				<a href="#dialog-buku" id="0" class="btn tambah" data-toggle="modal">
					<i class="icon-plus"></i> Tambah Data Buku
				</a>
			</p>
		</h3>

		<!-- tempat untuk menampilkan data Buku -->
		<div id="data-buku"></div>
	</div>
</div
<!-- awal untuk modal dialog -->
<div id="dialog-buku" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal" aria-hidden="true">X</button>
		<h3 id="myModalLabel">Tambah Data Buku</h3>
	</div>
	<!-- tempat untuk menampilkan form Buku -->
	<div class="modal-body"></div>
	<div class="modal-footer">
		<button class="btn btn-danger" data-dismiss="modal" aria-hidden="true">Batal</button>
		<button id="simpan-buku" class="btn btn-success">Simpan</button>
	</div>
</div>
<hr>
	<div class="footer-bottom">
		<div class="form-group">
			<div class="col-sm-4-offset-2" style="background-color: #fffffe;">
<p><center>Desaigned by &middot; SMAKKERZ </center></p>
	<ul class="nav nav-pills nav-stacked">
		<li class="active">
			<a href="#"><div class="icon-user"></div>INFO</a></li>
		<li><a href="#">E-mail : yusufadhi77@gmail.com OR yusufadhi7@ymail.com</a></li>
		<li><a href="#">Contact Person(WA) : 089 66 44 51 557</a></li>
		<li><a href="#">Line : _you7</a></li>
		<li><a href="#">Pin BBM : 54087411</a></li>
	</ul>
			</div>
	<div class="footer-bottom">
		<div class="container">
			<div class="col-sm-4">
				<p class="pull-left">Versi Beta 1.61 </p> <i class="icon-globe"></i>
				<p class="pull-right">&copy; Yusuf Adhi Tomo &middot; 2015 || E-mail : yusufadhi77@gmail.com / yusufadhi7@ymail.com<span></span></p>
			</div>
		</div>
	</div> 
</div>
</div>
<!-- akhir kode modal dialog -->

<!-- memanggil berkas javascript yang dibutuhkan -->
<script src="jquery-1.8.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="aplikasi.js"></script>
</body>
</html>
