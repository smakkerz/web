<?php
if (!$user->sesi()) {
	header("location:index.php");
}
?>
<div class="row">
	<a href="?page" class="btn btn-info"><i class="icon-calendar"></i> 
		<?php
			date_default_timezone_set('Asia/Jakarta');
			$tanggal= mktime(date("m"),date("d"),date("Y"));
			$tgl = date("d-m-Y", $tanggal);
			echo $tgl 
		?> 
	</a>
	<a href="?page=out" class="btn btn-success"><i class="icon-remove"></i>Keluar</a>
</div>