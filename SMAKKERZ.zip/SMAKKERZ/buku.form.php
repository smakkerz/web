<?php
error_reporting(E_ALL ^ E_DEPRECATED);
// panggil file koneksi.php
require 'koneksi.php';

// buat koneksi ke database mysql
$db = new database();
$db->koneksi_buka();

// tangkap variabel kd_buku
$id = $_POST['id'];

// query untuk menampilkan Buku berdasarkan kd_buku
$data = mysql_fetch_array(mysql_query("SELECT * FROM buku WHERE id =".$id));

// jika kd_buku > 0 / form ubah data
if($id > 0) { 
	$penerbit = $data['penerbit'];
	$penyusun = $data['penyusun'];
	$judul = $data['judul'];
	$kategori = $data['kategori'];
	$stock = $data['stock'];
	$harga = $data['harga'];
	$sekilas = $data['sekilas'];

//form tambah data
} else {
	$penerbit ="";
	$penyusun ="";
	$judul ="";
	$kategori ="";
	$stock ="";
	$harga = "";
	$sekilas = "";
}

?>
<form class="form-horizontal" id="form-buku" >
	<div class="control-group">
		<label class="control-label" for="penerbit">Penerbit</label>
		<div class="controls">
			<input type="text" id="penerbit" class="input-medium" name="penerbit" value="<?php echo $penerbit ?>" >
		</div>
	</div>
	<div class="control-group">
		<label class="control-label" for="penyusun">Penyusun</label>
		<div class="controls">
			<input type="text" id="penyusun" class="input-medium" name="penyusun" value="<?php echo $penyusun ?>" >
		</div>
	</div>
	<div class="control-group">
		<label class="control-label" for="judul">Judul</label>
		<div class="controls">
			<input type="text" id="judul" class="input-medium" name="judul" value="<?php echo $judul ?>" >
		</div>
	</div>
	<div class="control-group">
		<label class="control-label" for="kategori">Kategori</label>
		<div class="controls">
			<select class="input-medium" name="kategori">
				<?php 
				// tampilkan untuk form ubah buku
				if($id > 0) { ?>
					<option value="<?php echo $kategori ?>"><?php echo $kategori ?></option>
				<?php } ?>
				<option value="Komik">Komik</option>
				<option value="Pengetahuan">Pengetahuan</option>
				<option value="Romansa">Romansa</option>
				<option value="Jurnal">Jurnal</option>
			</select>
		</div>
	</div>
	<div class="control-group">
		<label class="control-label" for="stock">Stock </label>
		<div class="controls">
					<input type="text" name="stock" class="input-small" value="<?php echo  $stock ?>" >			
		</div>
	</div>
	<div class="control-group">
		<label class="control-label" for="harga">Harga </label>
		<div class="controls">
					Rp. <input type="text" name="harga" class="input-medium" value="<?php echo  $harga ?>" >			
		</div>
	</div>
	<div class="control-group">
		<label class="control-label" for="sekilas">Deskripsi Buku </label>
		<div class="controls">
			<input type="Text" class="input-large" name="sekilas" value="<?php echo  $sekilas ?>">
		</div>
	</div>
</form>