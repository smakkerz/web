

<div id="visimisi" class="container-fluid">
  <div class="row">
    <div class="col-sm-8">
      <h1>VISI</h1>
	  
	  
      
      
<div id="myCarousel" class="carousel slide text-center" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel" data-slide-to="1"></li>
    <li data-target="#myCarousel" data-slide-to="2"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
    <h4>"Berprestasi"<br><span style="font-style:normal;"></span></h4>
    </div>
    <div class="item">
      <h4>"Terampil"<br><span style="font-style:normal;"></span></h4>
    </div>
    <div class="item">
      <h4>"Berakhlak Mulia berdasarkan Iman dan Taqwa"<br><span style="font-style:normal;"></span></h4>
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
	  
	  
	  
	  <h1>MISI</h1>
	  
		
		
		<div id="myCarousel2" class="carousel slide text-center" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#myCarousel2" data-slide-to="0" class="active"></li>
    <li data-target="#myCarousel2" data-slide-to="1"></li>
    <li data-target="#myCarousel2" data-slide-to="2"></li>
	<li data-target="#myCarousel2" data-slide-to="3"></li>
    <li data-target="#myCarousel2" data-slide-to="4"></li>
	<li data-target="#myCarousel2" data-slide-to="5"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
    <h4>"Menciptakan suasana yang kondusif untuk membentuk 
	<br/>kepribadian peserta didik agar memiliki Iman dan Taqwa"<br><span style="font-style:normal;"></span></h4>
    </div>
    <div class="item">
      <h4>"Mengoptimalkan pembelajaran Aktif, Kreatif, dan Menyenangkan 
	  <br/>(PAKEM)"<br><span style="font-style:normal;"></span></h4>
    </div>
    <div class="item">
      <h4>"Mengembangkan pengetahuan di bidang IPTEK, Bahasa, Olahraga <br/>
	  dan seni Budaya sesuai dengan Potensi Siswa"<br><span style="font-style:normal;"></span></h4>
    </div>
	<div class="item">
      <h4>"Menggalakkan kegiatan Ekstrakurikuler sesuai dengan <br/>Potensi siswa"<br><span style="font-style:normal;"></span></h4>
    </div>
	<div class="item">
      <h4>"Menjalin kerjasama yang harmoni antar Warga, Masyarakat <br/>
	  dan Lingkungan sekitar"<br><span style="font-style:normal;"></span></h4>
    </div>
	<div class="item">
      <h4>"Menggerakkan budaya tertib, budaya bersih, dan budaya kerja 
	  <br/>(GERAKAN DISIPLIN NASIONAL)"<br><span style="font-style:normal;"></span></h4>
    </div>
  </div>

  <!-- Left and right controls -->
  <a class="left carousel-control" href="#myCarousel2" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel2" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
		
		
		
    </div>
    <div class="col-sm-4 col4">
      <span class="glyphicon glyphicon-flag logo"></span>
    </div>
  </div>
</div>
















