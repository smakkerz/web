<div class="container-fluid bg-1 text-center">
  <h1>SDN FUCK</h1>
  <h3>Pondok Bahagia</h3>
</div>

<div class="container-fluid bg-2 text-center">
  
  <div class="row">
    <div class="col-sm-8">
		<h2>JL. Lurus diBengko Bengkoin</h2>
		<h2>Kec. Pondok Bahagia</h2>
    </div>
    <div class="col-sm-4 col4">
      <span class="glyphicon glyphicon-home logo"></span>
    </div>
  </div>
  
</div>