<footer class="container-fluid bg-4 text-center">
  <p>CopyRight 2016 by Fadly Rifai | SDN Jatimurni VI</p> 
</footer>