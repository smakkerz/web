  <!-- Services Section -->
    <section id="services">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Visi & Misi</h2>
                    <h3 class="section-subheading text-muted">Berisi daftar berita/informasi terbaru.</h3>
                </div>
            </div>
            <div class="row text-center">
                <div class="col-md-3">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-shopping-cart fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="service-heading">Visi</h4>
                    <p class="text-muted">Sebagai lembaga Pendidikan Dasar lanjutan Islam terkemuka dalam menanamkan nilai- nilai islam untuk mempersiapkan kader umat yang siap berkembang menjadi generasi Khaira Ummah.</p>
                </div>
                <div class="col-md-3">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-laptop fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="service-heading">Misi</h4>
                    <p class="text-muted">Mengembangkan konsep operasional kader umat yang siap berkembang menjadi generasi Khaira Ummah, dan proses pendidikannya.</p>
                </div>
                <div class="col-md-3">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="service-heading">Misi</h4>
                    <p class="text-muted">Mengembangkan kualitas sejalan dengan nilai – nilai Islam dan perkembangan mutakhir ilmu pengetahuan dan teknologi ( IPTEK ).</p>
                </div>
                <div class="col-md-3">
                    <span class="fa-stack fa-4x">
                        <i class="fa fa-circle fa-stack-2x text-primary"></i>
                        <i class="fa fa-lock fa-stack-1x fa-inverse"></i>
                    </span>
                    <h4 class="service-heading">Misi</h4>
                    <p class="text-muted">Menjadikan kemajuan dan keberhasilan peserta didik dalam proses pendidikan sebagai pusat orientasi dan tujuan yang paling diutamakan dalam semua kegiatan.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Portfolio Grid Section -->
    <section id="portfolio" class="bg-light-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Galeri</h2>
                    <h3 class="section-subheading text-muted">Daftar kegiatan diluar pendidikan formal.</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6 portfolio-item">
                    <a href="#portfolioModal1" class="portfolio-link" data-toggle="modal">
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content">
                                <i class="fa fa-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="<?php echo base_url() ?>/assets/img/portfolio/roundicons.png" class="img-responsive" alt="">
                    </a>
                    <div class="portfolio-caption">
                        <h4>Gedung Pertemuan</h4>
                        <p class="text-muted">SMP Islam Sultan Agung 1</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 portfolio-item">
                    <a href="#portfolioModal2" class="portfolio-link" data-toggle="modal">
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content">
                                <i class="fa fa-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="<?php echo base_url() ?>/assets/img/portfolio/startup-framework.png" class="img-responsive" alt="">
                    </a>
                    <div class="portfolio-caption">
                        <h4>Permainan musik tradisional</h4>
                        <p class="text-muted">pada Hari Guru</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 portfolio-item">
                    <a href="#portfolioModal3" class="portfolio-link" data-toggle="modal">
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content">
                                <i class="fa fa-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="<?php echo base_url() ?>/assets/img/portfolio/treehouse.png" class="img-responsive" alt="">
                    </a>
                    <div class="portfolio-caption">
                        <h4>Acara Sungkeman Siswa siswi</h4>
                        <p class="text-muted">pada Hari Guru</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 portfolio-item">
                    <a href="#portfolioModal4" class="portfolio-link" data-toggle="modal">
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content">
                                <i class="fa fa-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="<?php echo base_url() ?>/assets/img/portfolio/golden.png" class="img-responsive" alt="">
                    </a>
                    <div class="portfolio-caption">
                        <h4>Kegiatan siswa siswa</h4>
                        <p class="text-muted">Di Simpang Lima Semarang</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 portfolio-item">
                    <a href="#portfolioModal5" class="portfolio-link" data-toggle="modal">
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content">
                                <i class="fa fa-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="<?php echo base_url() ?>/assets/img/portfolio/escape.png" class="img-responsive" alt="">
                    </a>
                    <div class="portfolio-caption">
                        <h4>Hari</h4>
                        <p class="text-muted">Kartini</p>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6 portfolio-item">
                    <a href="#portfolioModal6" class="portfolio-link" data-toggle="modal">
                        <div class="portfolio-hover">
                            <div class="portfolio-hover-content">
                                <i class="fa fa-plus fa-3x"></i>
                            </div>
                        </div>
                        <img src="<?php echo base_url() ?>/assets/img/portfolio/dreams.png" class="img-responsive" alt="">
                    </a>
                    <div class="portfolio-caption">
                        <h4>Ruang Ruang</h4>
                        <p class="text-muted">SMP Islam Sultan Agung 1</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">Sejarah Kami</h2>
                    <h3 class="section-subheading text-muted">.</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <ul class="timeline">
                        <li>
                            <div class="timeline-image">
                             
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4>Awal 1950</h4>
                                    <h4 class="subheading">Awal berdiri</h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted">SMP Islam Sultan Agung 1 Semarang adalah sebuah lembaga Pendidikan Islam yang berada di bawah pengelolaan Yayasan Badan Wakaf Sultan Agung (YBWSA) yang didirikan dengan akte notaris Raden Mas Soetomo Soeprapto, SH dengan no. 86 tahun 1950 no. 15 tahun 1989.</p>
                                </div>
                            </div>
                        </li>
                        <li class="timeline-inverted">
                            <div class="timeline-image">
                                
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4>Akhir 1950</h4>
                                    <h4 class="subheading">Keberadaan</h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted">Keberadaan SMP Islam Sultan Agung 1 ini tidak lepas dan tidak dapat dipisahkan dari sejarah TK Al-Falah yang didirikan pada tahun 1950 oleh Ustadz Tahir Nuri dan Abu Bakar Assegaf yang terletak di kampung Mustraman.</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="timeline-image">
                                
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4>1970</h4>
                                    <h4 class="subheading">Generasi awal</h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted">Pada tahun 1970 oleh pihak murid – murid dicoba untuk diikutsertakan pada ujian Sekolah Menengah Pertama dan ternyata hampir 100% pesertanya berhasil lulus ujian. Sejak saat itu dengan berbagai pertimbangan, akhirnya pada tahun itu juga Sekolah Menengah Diniyah dirubah menjadi SMP Badan Wakaf 1 Semarang.</p>
                                </div>
                            </div>
                        </li>
                        <li class="timeline-inverted">
                            <div class="timeline-image">
                               
                            </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4>1972</h4>
                                    <h4 class="subheading">Ujian mandiri</h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted">sekolah ini diberikan kepercayaan untuk menyelenggarakan ujian sendiri.</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="timeline-image">
                                </div>
                            <div class="timeline-panel">
                                <div class="timeline-heading">
                                    <h4>1988 - 1989</h4>
                                    <h4 class="subheading">Perkembangan terakhir</h4>
                                </div>
                                <div class="timeline-body">
                                    <p class="text-muted">Dalam perkembangannya selanjutnya karena kuantitas murid yang semakin bertambah, sedang ruangan yang ada pada waktu itu terbatas, maka oleh pihak yayasan pada tahun 1988/1989 SMP Badan Wakaf 1 Semarang dipindah ke jalan Seroja Selatan No. 14 A, yang memiliki fasilitas, sarana dan prasarana belajar yang lebih baik.</p>
                                </div>
                            </div>
                        </li>
                        
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- Team Section -->
    <section id="team" class="bg-light-gray">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <h2 class="section-heading">SMP Islam Sultan Agung 1</h2>
                    <h3 class="section-subheading text-muted">Sebagai lembaga pendidikan, SMP Islam Sultan Agung 1 Semarang tanggap dengan perkembangan teknologi tersebut. Dengan dukungan SDM yang di miliki sekolah ini siap untuk berkompetisi dengan sekolah lain dalam pelayanan informasi publik. Teknologi Informasi Web khususnya, menjadi sarana bagi SMP Islam Sultan Agung 1 Semarang untuk memberi pelayanan informasi secara cepat, jelas, dan akuntable. Dari layanan ini pula, sekolah siap menerima saran dari semua pihak yang akhirnya dapat menjawab Kebutuhan masyarakat</h3>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-4">
                    <div class="team-member">
                        
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="team-member">
                        <img src="<?php echo base_url() ?>/assets/img/2.jpg" class="img-responsive img-circle" alt="">
                        <h4>Kepala Sekolah</h4>
                        <p class="text-muted">Zaenuri S.Pd</p>
                        
                        </ul>
                    </div>
                </div>
               
                    </div>
                </div>
            </div>
           
            </div>
        </div>
    </section>