<!doctype html>
<html>
<head>
	
	<title>SMP - ISA 1</title>
	
<style>
            .container {
                position: relative;
                min-height: 100%;
            }
            h1 {
                font-size: 22px;
                font-family: Arial,Cambria, Georgia, serif,Sans-serif;
                text-align: center;
                margin-bottom: 4px;
            }
            .text {
                text-align: center;
                font-size: 12px;
            }
            .text .mail {
                color: #908;
                text-decoration: underline;
                margin: 5px;
            }
            hr {
                border-style: 3px solid;
                margin-bottom: 2px;
            }
            h2 {
                font-size: 17px;
                font-family: Sans-serif;
            }
            .word-table {
                border:1px dotted black !important; 
                border-collapse: collapse !important;
            }
            .word-table tr th{
                font-size: 15px;
            }
            .word-table tr th, .word-table tr td{
                border: 1px solid black !important; 
                padding: 5px 5px;
            }
            .styles {
                color: red;
                font-weight: bold;
            }
            .foot {
                bottom: 15px;
                position: absolute;
                font-size: 14px;
                width: 93%;
                text-align: center;
            }
        </style>
    
</head>

<body class="container">
<h3 style="text-align: center;">
<b style="font-size: 13px; margin-left: 130px;">YAYASAN BADAN WAKAF SULTAN AGUNG</b><br>
<img src="<?php echo base_url('uploads/kk/logo.jpg') ?>" style="height:80px;float: left;"> 
BIDANG PENDIDIKAN DASAR DAN MENENGAH <br>
SMP ISLAM SULTAN AGUNG 1<br>
TERAKREDITASI "A" <br>
<b style="font-size: 13px;">Jalan Seroja Selatan No 14A Semarang Telpn (024) 8316843 </b></h3>
<hr>
<H4 style="text-align: center;">FORMULIR PENDAFTARAN PESERTA DIDIK BARU <br/>SMP Islam Sultan Agung 1 Semarang<br>
Tahun Pelajaran <?php $tahun = date("Y");
						$sblm = 2017-1;
						echo $sblm.' - '.$tahun;?></H4>
<table >

	<tr>
		<td colspan="3" align="center"><h4>DATA SISWA</h4></td>
	</tr>
	<tr>
		<th style="width: 105px;">Nomor Pendaftaran</th>
		<td style="width:10px;"> : </td>
		<td><?php echo $peserta->no_pendaftaran."-".$peserta->id_peserta;?></td>
		<td rowspan="5"><img src="<?php echo base_url('uploads/kk/'.$peserta->dokumen); ?>" style="height:120px;"></td>
	</tr>
	<tr>
		<th>Nomor Induk Siswa Nasional(NISN)</th>
<td style="width:10px;"> : </td>
		<td><?php echo $peserta->nik;?></td>
	</tr>
	<tr>
		<th>Nama Lengkap</th>
<td style="width:10px;"> : </td>
		<td><?php echo $peserta->nama_lengkap;?></td>
	</tr>
	<tr>
		<th>Jenis Kelamin</th>
<td style="width:10px;">  : </td>
		<td><?php echo $peserta->jenis_kelamin;?></td>
	</tr>
	<tr>
		<th>Tempat Lahir</th>
<td style="width:10px;">  : </td>
		<td><?php echo $peserta->tempat_lahir;?></td>
	</tr>
	<tr>
		<th>Tanggal Lahir</th>
<td style="width:10px;">  : </td>
		<td><?php echo $peserta->tanggal_lahir."/ ".$peserta->bulan_lahir."/ ".$peserta->tahun_lahir;?></td>
	</tr>
	<tr>
		<th>Agama</th>
<td style="width:10px;">  : </td>
		<td><?php echo $peserta->agama;?></td>
	</tr>
	<tr>
		<th>No Ijazah/SKHUN</th>
<td style="width:10px;">  : </td>
		<td><?php echo $peserta->no_ijazah;?></td>
	</tr>
	<tr>
		<th>Total Nilai SKHUN</th>
<td style="width:10px;">  : </td>
		<td><?php echo $peserta->jumlah_skhun;?></td>
	</tr>
	<tr>
		<th>Asal Sekolah</th>
<td style="width:10px;">  : </td>
		<td><?php echo $peserta->asal_sekolah;?></td>
	</tr>
	<tr>
		<th>Alamat Sekolah</th>
<td style="width:10px;">  : </td>
		<td><?php echo $peserta->alamat_sekolah;?></td>
	</tr>
	<tr>
		<th>Telah mendaftar di </th>
<td style="width:10px;">  : </td>
		<td><?php echo $peserta->mendaftar;?></td>
	</tr>
	<tr>
		<td colspan="3" align="center"><h4>DATA ORANG TUA</h4></td>
	</tr>
	<tr>
		<th>Nama Orang Tua/Wali</th>
<td style="width:10px;"> : </td>
		<td><?php echo $peserta->nama_ortu;?></td>
	</tr>
	<tr>
		<th>Alamat Orang Tua/Wali</th>
<td style="width:10px;">  : </td>
		<td><?php echo $peserta->alamat_ortu;?></td>
	</tr>
	<tr>
		<th>Pekerjaan Orang Tua/Wali</th>
<td style="width:10px;">  : </td>
		<td><?php echo $peserta->pekerjaan_ortu;?></td>
	</tr>
	<tr>
		<th>No Handphone/Telp</th>
<td style="width:10px;"> : </td>
		<td><?php echo $peserta->no_handphone;?></td>
	</tr>
</table>
<hr>
<table class="table table-striped table-responsive table-bordered">
	<tr>
		<td colspan="9" align="center"><H4>KARTU PENDAFTARAN UJIAN<br/>SMP Islam Sultan Agung 1 Semarang</H4></td>
	</tr>
	<tr>
		<th style="width:40%;">Nomor Pendaftaran</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->no_pendaftaran."-".$peserta->id_peserta;?></td>
		<td rowspan="6"><img style="height:120px;" src="<?php echo base_url('uploads/kk/'.$peserta->dokumen); ?>" align="right"></td>
	</tr>
	<tr>
		<th style="width:40%;">Kelompok</th>
		<td style="width:1%;">:</td>
		<td>Kelompok <?php $t=explode("-", $peserta->no_pendaftaran); echo $t[1];?></td>
	</tr>
	<tr>
		<th style="width:40%;">Asal Sekolah</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->asal_sekolah;?></td>
	</tr>
	<tr>
		<th style="width:40%;">Alamat Rumah</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->alamat_ortu;?></td>
	</tr>
	<tr>
		<th style="width:40%;">Total Nilai SKHUN</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->jumlah_skhun;?></td>
	</tr>
</table>
</body>
</html>