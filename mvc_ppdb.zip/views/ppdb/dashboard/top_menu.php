<nav class="navbar navbar-inverse">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a style="color: white;" class="navbar-brand" href="<?php echo site_url('ppdb');?>"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Beranda</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <li class="hidden">
                        <a href="#page-top"></a>
                    </li>
        <li><a style="color: white;" href="<?php echo site_url('ppdb/daftarpeserta');?>"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Peserta</a></li>
        <li class="dropdown">
          <a href="#" style="color: white;"  class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span> Informasi <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo site_url('ppdb/prosedur');?>"><span class="glyphicon glyphicon-bookmark" aria-hidden="true"></span> Prosedur</a></li>
            <li role="separator" class="divider"></li>
            <li><a  href="<?php echo site_url('ppdb/pengumuman');?>"><span class="glyphicon glyphicon-bullhorn" aria-hidden="true"></span> Pengumuman</a></li>
			<li><a href="<?php $thn = date("Y");
        $id = substr($thn, 2);
         echo site_url('ppdb/jadwal/'.$id.'-01');?>"><span class="glyphicon glyphicon-calendar" aria-hidden="true"></span> Jadwal</a></li>
          </ul>
        </li>
		<li class="dropdown">
          <a href="#" style="color: white;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphicon-question-sign" aria-hidden="true"></span> Bantuan <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo site_url('ppdb/pertanyaan');?>"><span class="glyphicon glyphicon-list-th" aria-hidden="true"></span> Pertanyaan</a></li>
            
          </ul>
        </li>
		<li class="dropdown">
          <a href="#" style="color: white;" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="glyphicon glyphstyle="color: white;" icon-question-user" aria-hidden="true"></span> Akun Saya <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo site_url('ppdb/form_biodata');?>"><span class="glyphicon glyphicon-edit" aria-hidden="true"></span> Biodata</a></li>
            <li><a href="<?php echo site_url('ppdb/form_preview');?>"><span class="glyphicon glyphicon-print" aria-hidden="true"></span> Cetak Biodata</a></li>
          </ul>
        </li>
      </ul>
	  
	  <ul class="nav navbar-nav navbar-right">
		<li><a style="color: white;" href="<?php echo site_url('ppdb/logout');?>"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span> <?php echo $this->session->userdata('id_peserta');?>(Logout)</a></li>
		</ul>
	  
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>


































