<h2>Berikut Pertanyaan yang sering diajukan</h2>
<hr>
    <ol><h4>
        <li>
            <strong>Bagaimana cara mendaftar di PSB Islam Sultan Agung 1 Semarang ?</strong>
            <br> Untuk langkah pertama silahkan membuat akun bisa di link >>
            <?php echo anchor('ppdb_controller/pendaftaran', 'Pendaftaran'); ?>,
            Kemudian calon peserta akan diarahkan untuk Login menggunakan username dan password yang telah didaftarkan untuk melengkapi Biodata. Selamat Anda telah mendaftar di PSB Islam Sultan Agung 1 Semarang.
        </li><br/>

        <li>
            <strong>Berapa jumlah siswa siswi yang akan diterima di SMP Islam Sultan Agung 1 Semarang ?</strong>
            <br> Jumlah siswa siswi yang diterima di SMP Islam Sultan Agung 1 Semarang  akan mengikuti kebijakan pihak sekolah.
        </li><br/>

        <li>
            <strong>Mengapa daftar peserta belum diverifikasi?</strong>
            <br> Dikarenakan biodata yang diisi belum lengkap, jadinya pihak Admin belum bisa memverifikasi daftar peserta.
        </li><br/>

        <li>
            <strong>Kapan siswa tau pengumuman dibuka?</strong>
            <br> Pada saat admin menghidupkan status pengumuman dan setelah selesai menyeleksi siswa yang lolos.
        </li><br/>

        <li>
            <strong>Dimana ruang yang peserta tempati untuk ujian ?</strong>
            <br> Itu Nantinya berdasarkan kelompok ,nantinya kelompok 1 ada 30 siswa yang mengikuti ujian, kemudian kelompok selanjutnya menyesuaikan.
        </li><br/>

        <li>
            <strong>Apakah peserta perlu mengisi telah mendaftar di (di bagian biodata) ?</strong>
            <br> Di bagian form biodata tersebut ada tanda bintang berarti wajib diisi , kalau tidak ada dikosongi.
        </li><br/>

        <li>
            <strong>Bagaimana cara peserta tau akun diverifikasi ?</strong>
            <br> 1. Pilih menu pendaftaran</br>
                 2. Klik Daftar</br>
                 3. Kemudian isi form tersebut dengan benar sesuai dengan ijazah peserta</br>
                 4. Klik Buat Akun</br>
                 5. Lalu akun anda langsung muncul di tampilan username dan password</br>
                 6. Klik masuk</br>
                 7. Maka akan masuk Ke Halaman Peserta</br>
                 8. Peserta mengisi biodata secara lengkap</br>
                 9. Klik Kirim</br>
                 10. Nantinya admin akan mengelola biodata peserta, jika biodata peserta sudah lengkap maka akan diverifikasi</br>
                 11. Nanti akun anda verifikasi akan muncul di halaman setelah login</br>
        </li><br/>

        <li>
            <strong>Bagaimana sejarah SMP Sultan Agung 1 Semarang ?</strong>
            <br> Silahkan anda lihat di halaman awal dan pilih sejarah kami, maka akan muncul sejarah SMP Islam Sultan Agung 1 Semarang
        </li><br/>

         <li>
            <strong>Apa Keunggulan akun yang sudah diverifikasi ?</strong>
            <br> 1. Peserta dapat mencetak biodata dan kartu ujian</br>
                 2. Peserta dapat mengikuti ujian</br>
        </li><br/>

 <li>
            <strong>Apa visi dan misi SMP Islam Sultan Agung 1 Semarang ?</strong>
            <br> Silahkan anda lihat di halaman awal dan pilih visi dan misi, maka akan muncul visi dan misi SMP Islam Sultan Agung 1 Semarang
        </li><br/>

         <li>
            <strong>Bagaimana cara melihat galeri SMP Islam Sultan Agung 1 Semarang ?</strong>
            <br>Silahkan anda lihat di halaman awal dan pilih galeri, maka akan muncul galeri SMP Islam Sultan Agung 1 Semarang
        </li><br/>

 <li>
            <strong>Bagaimana cara melihat pengumuman di SMP Islam Sultan Agung 1 Semarang?</strong>
            <br> 1. Silahkan anda lihat di halaman awal dan pilih Pendaftaran</br>  
                 2. Pilih Menu Informasi </br>
                 3. Klik Pengumuman</br>
                 4. maka akan muncul Pengumuman peserta yang diterima di SMP Islam Sultan Agung 1 Semarang</br>  
        </li><br/>


 <li>
            <strong>Bagaimana cara melihat peserta lain ?</strong>
            <br>  1. Silahkan anda lihat di halaman awal dan pilih Pendaftaran</br>  
                  2. Klik Peserta</br>
                  3. maka akan muncul peserta lain </br>
        </li><br/>

        
    </h4></ol>
    <h4><strong>Jika pertanyaan tidak ada di atas silahkan kirim kontak anda ke admin dengan mengisi form <?php echo anchor('ppdb/kontak', 'kontak'); ?>. Maka anda akan dihubungi melalui nomor telepon yang telah dikirimkan</strong></h4>