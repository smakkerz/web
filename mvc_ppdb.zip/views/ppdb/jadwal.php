<div class="container-fluid">
<h3  style="text-align: center;" class="lighter blue">Jadwal Pendaftaran Peserta Didik Baru SMP Islam Sultan Agung 1 Semarang </h3>
<?php
	$pengumuman = $pengumuman->status;
	if ($pengumuman == 'dihidupkan')
	{ 
		foreach ($menu as $key) {
			if(count($key) < 1){
				$t = explode("-", $key->kelompok);
	?>
	<ul class="nav nav-pills">
	<?php ?>
	<li><a href="<?php echo site_url('ppdb/jadwal/'.$key->kelompok);?>"><b>Kelompok <?= $t[1]; ?></b></a></li>
	<?php  } } $t = explode("-", $jadwal->kelompok); ?>
	</ul>
		<h3 class="header smaller lighter blue">Ruang : <b><?= $jadwal->ruang ?></b>
		Waktu : <b><?= $jadwal->jam ?> WIB, <?=$jadwal->tgl ?></b>
		Kelompok : <b><?= $t[1] ?></b></h3>
		<table class="table table-striped table-bordered data">
			<thead>
				<tr>			
					<th width="99px">No Ujian</th>
					<th>Nama Lengkap</th>
					<th>NISN</th>
					<th>Asal Sekolah</th>
					<th>No Ijazah</th>
					<th>Nilai UN</th>
					<th>Alamat Tinggal</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($peserta as $peserta)
				{
				?>
				<tr>
					<td><?php echo $peserta->no_pendaftaran."-".$peserta->id_peserta;?></td>
					<td><?php echo $peserta->nama_lengkap;?></td>
					<td><?php echo $peserta->nik;?></td>
					<td><?php echo $peserta->asal_sekolah;?></td>
					<td><?= $peserta->no_ijazah ?></td>
					<td><?= $peserta->jumlah_skhun ?></td>
					<td><?= $peserta->alamat_ortu ?></td>
				</tr>
				<?php
				}
				?>
			</tbody>
		</table>
	<?php
	}
	else
	{
	?>
		<div class="alert alert-danger" role="alert">Maaf Jadwal belum dibuka</div>
	<?php
	}
?>
	</div>