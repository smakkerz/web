<div class="container">
<h3 class="header smaller lighter blue">Pengumuman Peserta yang lulus seleksi : </h3>
<?php
	$pengumuman = $pengumuman->status;
	if ($pengumuman == 'dihidupkan')
	{
	?>
		<table class="table table-striped table-bordered">
			<thead>
				<tr>			
					<th width="99px">No Ujian</th>
					<th>Ranking</th>
					<th>Nama Lengkap</th>
					<th>NISN</th>
					<th>Asal Sekolah</th>
					<th>Nilai</th>
					<th width="75px">Keterangan</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($peserta as $peserta)
				{
				?>
				<tr>
					<td>F<?php echo $peserta->no_pendaftaran."-".$peserta->id_peserta;?></td>
					<td><?php echo $peserta->rank ?></td>
					<td><?php echo $peserta->nama_lengkap;?></td>
					<td><?php echo $peserta->nik;?></td>
					<td><?= $peserta->asal_sekolah; ?></td>
					<td><?= $peserta->nilai; ?></td>
					<td><?php echo $peserta->keterangan;?></td>
				</tr>
				<?php
				}
				?>
			</tbody>
		</table>
	<?php
	}
	else
	{
	?>
		<div class="alert alert-danger" role="alert">Maaf Pengumuman belum dibuka</div>
	<?php
	}
?>

		
	</div>