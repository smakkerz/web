<div class="container">
		<table class="table table-striped table-bordered data">
			<thead>
				<tr>			
					<th width="100px">No Ujian</th>
					<th>NISN</th>
					<th>Nama Lengkap</th>
					<th>Asal Sekolah</th>
					<th>No Ijazah</th>
					<th>Nilai UN</th>
					<th>Alamat Tinggal</th>
					<th>Ranking</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($peserta as $peserta)
				{
				?>
				<tr>
					<td>F<?php echo $peserta->no_pendaftaran."-".$peserta->id_peserta;?></td>
					<td><?php echo $peserta->nik;?></td>
					<td><?php echo $peserta->nama_lengkap;?></td>
					<td><?php echo $peserta->asal_sekolah?></td>
					<td><?php echo $peserta->no_ijazah; ?></td>
					<td><?php echo $peserta->jumlah_skhun; ?></td>
					<td><?php echo $peserta->alamat_ortu;?></td>
					<td><?= $peserta->rank ?></td>
				</tr>
				<?php
				}
				?>
			</tbody>
		</table>
	</div>