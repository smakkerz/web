<div class="container">
								<h3 class="header smaller lighter blue"><?php echo $pesan->nama;?>   
								<small>&nbsp;  >> No yang bisa dihubungi <b class="lighter blue"><?php echo $pesan->nope;?></b></small></h3>
								<div class="well well-lg">Judul &nbsp; >> <b class="lighter blue"><?php echo $pesan->judul; ?></b>
								<h3 class="header smaller lighter blue">Isi Pesan</h3><?php echo $pesan->isi;?></div>
	</div>