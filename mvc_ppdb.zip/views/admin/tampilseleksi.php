<div class="container-fluid">
	<a href="<?php echo site_url('admin/tambah');?>" class="btn btn-sm btn-primary">Tambah</a>
								<h3 class="header smaller lighter blue">Daftar Keseluruhan Peserta yang ikut Ujian : </h3>
								<table class="table table-striped table-bordered data">
			<thead>
				<tr>			
					<th>No Ujian</th>
					<th>Nama Peserta</th>
					<th>Total Nilai</th>
					<th>Status</th>
					<th>Keterangan</th>
					<th>Rangking</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($pesan as $pesan)
				{
					if(empty($pesan->keterangan)) {
						$status = '<div class="btn-group">
												<button data-toggle="dropdown" >
													Status
													<span class="icon-caret-down icon-on-right"></span>
												</button>

												<ul class="dropdown-menu dropdown-info dropdown-menu-right">
													<li>
														<a href="update/'.$pesan->id_peserta.'/LULUS">Diterima</a>
													</li>

													<li>
														<a href="update/'.$pesan->id_peserta.'/GAGAL">Gagal</a>
													</li>
												</ul>
											</div><!-- /.btn-group -->';
					} else {
						$status = $pesan->keterangan;
					}
					if(empty($pesan->daftar_ulang) OR $pesan->daftar_ulang == "BELUM" ) {
						$du = '<div class="btn-group">
												<button data-toggle="dropdown" >
													Daftar Ulang
													<span class="icon-caret-down icon-on-right"></span>
												</button>

												<ul class="dropdown-menu dropdown-info dropdown-menu-right">
													<li>
														<a href="update1/'.$pesan->id_seleksi.'/SUDAH">Sudah</a>
													</li>

													<li>
														<a href="update1/'.$pesan->id_seleksi.'/BELUM">Belum</a>
													</li>
												</ul>
											</div><!-- /.btn-group -->';
					} else {
						$du = $pesan->daftar_ulang;
					}
				?>
					<tr>
						<td><b>F<?php echo $pesan->no_pendaftaran."-".$pesan->id_peserta;?></b></td>
						<td><b><?php echo $pesan->nama_lengkap;?></b></td>
						<td><b><?php echo $pesan->nilai;?></b></td>
						<td><b><?php echo $status;?></b></td>
						<td><b><?php echo $du;?></b></td>
						<td><b><?php if($status == "GAGAL"){
							echo "-"; }
							else {
								echo $pesan->rank;
								} ?></b></td>
						<td><a href="<?php echo site_url('admin/hapus_seleksi/'.$pesan->id_seleksi);?>">Hapus</a> | 
					</tr>
				<?php
				
				}
				?>
			</tbody>
		</table>
	</div>