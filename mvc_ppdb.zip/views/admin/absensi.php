<!doctype html>
<html>
<head>
	
	<title>SMP - ISA 1</title>
	
<style>
            .container {
                position: relative;
                min-height: 100%;
            }
            h1 {
                font-size: 22px;
                font-family: Arial,Cambria, Georgia, serif,Sans-serif;
                text-align: center;
                margin-bottom: 4px;
            }
            .text {
                text-align: center;
                font-size: 12px;
            }
            .text .mail {
                color: #908;
                text-decoration: underline;
                margin: 5px;
            }
            hr {
                border-style: 3px solid;
                margin-bottom: 2px;
            }
            h2 {
                font-size: 17px;
                font-family: Sans-serif;
            }
            .word-table {
                border:1px solid black !important; 
            }
            .word-table tr th{
                font-size: 15px;
            }
            .word-table tr th, .word-table tr td{
                border: 1px solid black !important; 
                padding: 5px 5px;
            }
            .styles {
                color: red;
                font-weight: bold;
            }
            .foot {
                bottom: 85px;
                position: absolute;
                font-size: 14px;
                width: 93%;
                text-align: right;
                margin-left: 509px;
            }
            .foot1 {
                bottom: 35px;
                position: absolute;
                font-size: 14px;
                width: 93%;
                text-align: right;
                margin-left: 540px;
            }
        </style>
    
</head>

<body class="container">
<h3 style="text-align: center;">
<b style="font-size: 13px;">YAYASAN BADAN WAKAF SULTAN AGUNG</b><br>
<img src="<?php echo base_url('uploads/kk/logo.jpg') ?>" style="height:85px;float: left;"> 
BIDANG PENDIDIKAN DASAR DAN MENENGAH <br>
SMP ISLAM SULTAN AGUNG 1<br>
TERAKREDITASI "A" <br>
<b style="font-size: 13px;">Jalan Seroja Selatan No 14A Semarang Telpn (024) 8316843 </b></h3>
<hr>
<h1>Daftar Hadir Peserta Didik Baru <br>
SMP Islam Sultan Agung 1 Semarang </h1>

<?php

		$t = explode("-", $jadwal->kelompok);
	?>
		<h3 style="text-align: center;">Ruang : <b><?= $jadwal->ruang ?></b>
		Waktu : <b><?= $jadwal->jam ?> WIB, <?=$jadwal->tgl ?></b>
		Kelompok : <b><?= $t[1] ?></b></h3>
		<table class="word-table">
			<thead>
				<tr>			
					<th style="width: 85px;">No Ujian</th>
					<th style="width: 145px;">Nama Lengkap</th>
					<th style="width: 120px;">NISN</th>
					<th style="width: 245px;">Tanda Tangan</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($peserta as $peserta)
				{
				?>
				<tr>
					<td><?php echo $peserta->no_pendaftaran."-".$peserta->id_peserta;?><br></td>
					<td><?php echo $peserta->nama_lengkap;?></td>
					<td><?php echo $peserta->nik;?></td>
					<td></td>
				</tr>
				<?php
				}
				?>
			</tbody>
		</table>
        <span class="foot">(Tanda Tangan Pengawas)</span>
        <span class="foot1"><?=$jadwal->keterangan_jadwal ?></span>
	</body>
</html>