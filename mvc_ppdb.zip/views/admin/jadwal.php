<div class="container-fluid">
	<div class="row">
	<a href="<?php echo site_url('admin/tjadwal');?>" class="btn btn-sm btn-primary">Tambah</a>
								<h3 class="header smaller lighter blue">Daftar Keseluruhan Kelompok Ujian : </h3>
								<table class="table table-striped table-bordered data">
			<thead>
				<tr>			
					<th>Kelompok</th>
					<th>Ruang</th>
					<th>Jam</th>
					<th>Tanggal</th>
					<th>Keterangan</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($jadwal as $pesan)
				{
					$t = explode("-", $pesan->kelompok);
				?>
					<tr>
						<td><b>Kelompok <?php echo $t[1];?></b></td>
						<td><b><?php echo $pesan->ruang;?></b></td>
						<td><b><?php echo $pesan->jam;?> WIB</b></td>
						<td><b><?php echo $pesan->tgl;?></b></td>
						<td><b><a href="<?php echo site_url('admin/lihat_jadwal/'.$pesan->kelompok);?>">Lihat</a></b></td>
						<td><a href="<?php echo site_url('admin/hapus_jadwal/'.$pesan->id_jadwal);?>">Hapus</a>
						| <a href="<?= site_url('admin/cetak_jadwal/'.$pesan->kelompok); ?>" target="blank"> Cetak</a> 
						| <a href="<?= site_url('admin/cetak_absensi/'.$pesan->kelompok); ?>" target="blank"> Cetak absensi</a> 
					</tr>
				<?php
				
				}
				?>
			</tbody>
		</table>
	</div>								
</div>