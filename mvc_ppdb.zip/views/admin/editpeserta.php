<div class="panel-heading">
    <h3 class="panel-title">Formulir Pendaftaran</h3>
  </div>
  <div class="panel-body">
  
   
  <h1>Data Siswa <span align="right">No Ujian : <b><?= $peserta->no_pendaftaran."-".$peserta->id_peserta; ?></b></span></h1>
<div class="progress" data-percent="">
												<div class="bar" style="width:100%;"></div>
											</div>

    
			<form class="form-horizontal" action="<?php echo site_url('admin/proseseditpeserta');?>" method="post">
	<div class="control-group">
		<label class="control-label" for="form-field-2">NISN</label>
		<div class="controls">
			<input type="text" id="form-field-2" placeholder="" name="nik" value="<?php echo $peserta->nik;?>" />						
		</div>
	</div>
  
	<div class="control-group">
    <label class="control-label" for="form-field-2">Nama Lengkap</label>
    <div class="controls">
      <input type="text" class="form-control" id="inputPassword3" placeholder="Nama" name="nama_lengkap" value="<?php echo $peserta->nama_lengkap;?>">
    </div>
  </div>
    
  <div class="form-group">
    <label class="control-label" for="form-field-2">Tempat Lahir</label>
    <div class="controls">
      <input type="text" class="form-control" id="inputPassword3" placeholder="Mis: Bekasi" name="tempat_lahir" value="<?php echo $peserta->tempat_lahir;?>">
    </div>
	</div>
	
	<div class="form-group">
    <label class="control-label" for="form-field-2"">tanggal Lahir</label>
    <div class="controls">
		<div class="col-sm-3">
			<input type="text" class="form-control" id="inputEmail3" name="tanggal_lahir" value="<?php echo $peserta->tanggal_lahir;?>" placeholder="Tanggal Lahir(xx)">
		</div>
		<div class="col-sm-4">
			<input type="text" class="form-control" id="inputEmail3" name="bulan_lahir" value="<?php echo $peserta->bulan_lahir;?>" placeholder="Bulan Lahir(xx)">
		</div>
		<div class="col-sm-4">
			<input type="text" class="form-control" id="inputEmail3" name="tahun_lahir" value="<?php echo $peserta->tahun_lahir;?>" placeholder="Tahun lahir(xxxx)">
		</div>
    </div>
  </div>

	
	<div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Agama</label>
    <div class="controls">
      <select class="form-control" name="agama">
			<option><?php echo $peserta->agama;?></option>
		  <option>Islam</option>
		  <option>Kristen</option>
		  <option>Katolik</option>
		  <option>Hindu</option>
		  <option>Buddha</option>
	</select>
    </div>
  </div>

  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">No Ijazah/SKHUN</label>
    <div class="controls">
      <input type="text" class="form-control" id="inputPassword3" placeholder="Nama" name="nama_panggilan" value="<?php echo $peserta->no_ijazah;?>">
    </div>
  </div>
  
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Total Nilai SKHUN</label>
    <div class="controls">
      <input type="int" class="form-control" id="inputPassword3" placeholder="misal 20.00" name="kewarganegaraan" value="<?php echo $peserta->jumlah_skhun;?>">
    </div>
  </div>
  
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Asal Sekolah (SD/MI/ Sederajatna)</label>
    <div class="controls">
      <input type="text" class="form-control" id="inputPassword3" placeholder="Cm" name="tinggi_badan" value="<?php echo $peserta->asal_sekolah;?>">
    </div>
  </div>
	
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Alamat Sekolah</label>
    <div class="controls">
      <textarea row="5" class="form-control" id="inputPassword3" name="alamat" value="<?php echo $peserta->alamat_sekolah;?>" placeholder="Alamat sekolah"><?php echo $peserta->alamat_sekolah;?></textarea>
    </div>
  </div>
  
    <div class="form-group">
    <label for="inputPassword3" class="col-sm-3 control-label">Telah mendaftar di</label>
    <div class="controls">
      <input type="number" class="form-control" id="inputPassword3" name="penghasilan" value="<?php echo $peserta->mendaftar;?>" placeholder="Misal SMP N XXX">
    </div>
  </div>
  

<h1>Data Orang Tua/Wali</h1>
<div class="progress">
  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">
    <span class="sr-only">100% Complete</span>
  </div>
</div>
    
	
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-3 control-label">Nama Orang Tua/Wali</label>
    <div class="controls">
      <input type="text" class="form-control" id="inputEmail3" name="nama_ayah" value="<?php echo $peserta->nama_ortu;?>" placeholder="Nama Ayah">
    </div>
  </div>
  
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-3 control-label">Alamat Orang Tua/Wali</label>
    <div class="controls">
      <input type="text" class="form-control" id="inputPassword3" name="pendidikan_ayah" value="<?php echo $peserta->alamat_ortu;?>" placeholder="Pendidikan Tertinggi Ayah">
    </div>
  </div>
  
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-3 control-label">Pekerjaan Orang Tua/Wali</label>
    <div class="controls">
      <input type="text" class="form-control" id="inputPassword3" name="pekerjaan_ibu" value="<?php echo $peserta->pekerjaan_ortu;?>" placeholder="PNS/TNI/Peg. Swasta/WiraSwasta/Petani/Buruh">
    </div>
  </div>

  <div class="form-group">
    <label for="inputPassword3" class="col-sm-3 control-label">No Handphone/Telp</label>
    <div class="controls">
      <input type="number" class="form-control" id="inputPassword3" name="no_handphone" value="<?php echo $peserta->no_handphone;?>" placeholder="Mis 0812.....">
    </div>
    </div> 


    <input type="hidden" name="id_peserta" value="<?php echo $peserta->id_peserta;?>"/>

<button type="submit" class="btn btn-primary btn-lg btn-block">Kirim</button>
</form>
	
	
	
  </div>