<ul class="nav nav-list">
					<li>
						<a href="<?php echo site_url('admin/daftarpeserta');?>">
							<i class="icon-dashboard"></i>
							<span class="menu-text"> Daftar Peserta </span>
						</a>
					</li>

					<li>
						<a href="<?php echo site_url('admin/daftarverifpeserta');?>">
							<i class="icon-text-width"></i>
							<span class="menu-text"> Verifikasi Peserta </span>
						</a>
					</li>

					<li>
						<a href="<?php echo site_url('admin/seleksi');?>">
							<i class="icon-list"></i>
							<span class="menu-text"> Daftar Peserta Ujian</span>
						</a>
					</li>
					
					<li>
						<a href="<?php echo site_url('admin/jadwal');?>">
							<i class="icon-list"></i>
							<span class="menu-text"> Jadwal </span>
						</a>
					</li>
					
					<li>
						<a href="<?php echo site_url('admin/daftarpesan');?>">
							<i class="icon-list-alt"></i>
							<span class="menu-text"> Pesan </span>
						</a>
					</li>

					<li>
						<a href="<?php echo site_url('admin/pengumuman');?>">
							<i class="icon-cogs"></i>
							<span class="menu-text"> Pengaturan </span>
						</a>
					</li>

					<li>
						<a href="<?php echo site_url('admin/laporan');?>">
							<i class="icon-list-alt"></i>
							<span class="menu-text"> Laporan </span>
						</a>
					</li>
													
				</ul>