<div class="panel panel-success">
  <div class="panel-heading">
    <h3 class="panel-title">Form Input Jadwal</h3>
  </div>
  <div class="panel-body">

<form action="<?php echo site_url('admin/tmbhjadwal');?>" method="post" class="form-horizontal">
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-2 control-label">Kelompok </label>
    <div class="col-sm-10">
     <select id="state" name="kelompok" class="form-control" required="required" data-placeholder="Click to Choose...">
                                    <option value="">&nbsp;</option>
                                    <?php 
                          foreach ($jadwal as $key) {
                            $t = explode("-", $key->no_pendaftaran);
                            echo "<option value='".$key->no_pendaftaran."'>".$t[1]."</option>";
                                    }
                        ?>
                                  </select>
    </div>
  </div>
  <br>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Ruang </label>
    <div class="col-sm-12">
      <input type="text" class="form-control" id="inputPassword3" placeholder="Ruang(xx)" name="ruang" >
      </div>
      </div>
      <br>
      <div class="form-group">
    <label for="inputPassword3" class="col-sm-2 control-label">Waktu </label>
    <div class="col-sm-10">
      <div class="col-sm-2">
      <input type="text" class="form-control" maxlength="5" id="inputEmail3" name="jam" placeholder="JAM(xx.xx)">
    </div>
    <br>
    <label for="inputPassword3" class="col-sm-2 control-label">Tanggal</label>
      <div class="col-sm-2">
      <input type="text" class="form-control" id="inputEmail3" name="tanggal" placeholder="Tanggal(xx-xx-xxxx)">
    </div>
    <label for="inputPassword3" class="col-sm-2 control-label">Nama Pengawas</label>
      <div class="col-sm-2">
      <input type="text" class="form-control" id="inputEmail3" name="pengawas" placeholder="Tanggal(xx-xx-xxxx)">
    </div>
      </div>
      </div>
      <div class="container-fluid">
    <button type="submit" class="btn btn-primary btn-sm">Kirim</button>
    </div>
    </form>
 </div>
 </div>