<table class="table table-striped table-responsive table-bordered">
 	 <img width="400px" src="<?php echo base_url('uploads/kk/'.$peserta->dokumen); ?>" align="right">
	<tr class="info">
		<td colspan="3" align="center"><h4>DATA SISWA</h4></td>
	</tr>
	<tr>
		<th style="width:20%;">Nomor Pendaftaran</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->no_pendaftaran."-".$peserta->id_peserta;?></td>
	</tr>
	<tr>
		<th>Nomor Induk Siswa Nasional(NISN)</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->nik;?></td>
	</tr>
	<tr>
		<th>Nama Lengkap</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->nama_lengkap;?></td>
	</tr>
	<tr>
		<th>Jenis Kelamin</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->jenis_kelamin;?></td>
	</tr>
	<tr>
		<th>Tempat Lahir</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->tempat_lahir;?></td>
	</tr>
	<tr>
		<th>Tanggal Lahir</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->tanggal_lahir."/ ".$peserta->bulan_lahir."/ ".$peserta->tahun_lahir;?></td>
	</tr>
	<tr>
		<th>Agama</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->agama;?></td>
	</tr>
	<tr>
		<th>No Ijazah/SKHUN</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->jumlah_skhun;?></td>
	</tr>
	<tr>
		<th>Total Nilai SKHUN</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->alamat_sekolah;?></td>
	</tr>
	<tr>
		<th>Asal Sekolah</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->asal_sekolah;?></td>
	</tr>
	<tr>
		<th>Alamat Sekolah</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->alamat_sekolah;?></td>
	</tr>
	<tr>
		<th>Telah Mendaftar di</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->mendaftar;?></td>
	</tr>
	<tr class="info">
		<td colspan="3" align="center"><h4>DATA ORANG TUA</h4></td>
	</tr>
	<tr>
		<th>Nama Orang Tua/Wali</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->nama_ortu;?></td>
	</tr>
	<tr>
		<th>Alamat Orang Tua/Wali</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->alamat_ortu;?></td>
	</tr>
	<tr>
		<th>Pekerjaan Orang Tua/Wali</th>
		<td style="width:1%;">:</td>
		<td><?php echo $peserta->pekerjaan_ortu;?></td>
	</tr>
	<tr>
		<th>No Handphone/Telp</th>
		<td style="width:1%;">:</td>
		<td> <?php echo $peserta->no_handphone;?></td>
	</tr>
	
	<tr>
		<th><a target="blank" class="btn btn-sm btn-primary" href="<?php echo site_url('admin/cetak/'.$peserta->id_peserta);?>">
		<i class="icon-download"></i> Cetak</a></th>
	</tr>
 
</table>