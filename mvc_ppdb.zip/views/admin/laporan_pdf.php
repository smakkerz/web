<html>
<head>
    
    <title>SMP - ISA 1</title>
    
<style>
            .container {
                padding: 2px;
                margin: 5px;
            }
            h1 {
                font-size: 22px;
                font-family: Arial,Georgia, serif,Sans-serif;
                text-align: center;
                margin-bottom: 14px;
            }
            .text {
                text-align: center;
                font-size: 12px;
            }
            .text .mail {
                color: #908;
                text-decoration: underline;
                margin: 5px;
            }
            hr {
                border-style: 3px solid;
                margin-bottom: 2px;
            }
            h2 {
                font-size: 17px;
                font-family: Sans-serif;
            }
            .word-table {
                border:1px solid black !important;
                text-align: center; 
            }
            .word-table tr th{
                font-size: 15px;
            }
            .word-table tr th, .word-table tr td{
                border: 1px solid black !important; 
                padding: 5px 5px;
            }
            .styles {
                color: red;
                font-weight: bold;
            }
            .foot {
                bottom: 15px;
                position: absolute;
                font-size: 14px;
                width: 93%;
                text-align: center;
            }
        </style>
    
</head>

<body class="container">
<h3 style="text-align: center;">
<b style="font-size: 13px; margin-left: 130px; ">YAYASAN BADAN WAKAF SULTAN AGUNG</b><br>
<img src="<?php echo base_url('uploads/kk/logo.jpg') ?>" style="width:85px;float: left;"> 
BIDANG PENDIDIKAN DASAR DAN MENENGAH <br>
SMP ISLAM SULTAN AGUNG 1<br>
TERAKREDITASI "A" <br>
<b style="font-size: 13px;">Jalan Seroja Selatan No 14A Semarang Telpn (024) 8316843 </b></h3>
<hr>
<h3 style="text-align: center;">Laporan Pendaftaran Peserta Didik Baru SMP Islam Sultan Agung 1 Semarang <br>
Tahun Pelajaran <?php $tahun = date("Y");
                        $sblm = 2017-1;
                        echo $sblm.' - '.$tahun;?></h3>
    <table class="word-table">
            <thead>
                <tr>            
                    <th width="50px">No Pendaftaran</th>
                    <th width="120px">Nama Peserta</th>
                    <th width="260px">Alamat Tinggal</th>
                    <th width="40px">Nilai Ujian</th>
                    <th width="50px">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($laporan as $pesan)
                {
                ?>
                    <tr>
                        <td><?php echo $pesan->no_pendaftaran."-".$pesan->id_peserta;?></td>
                        <td><?php echo $pesan->nama_lengkap;?></td>
                        <td><?php echo $pesan->alamat_ortu; ?></td>
                        <td><?php echo $pesan->nilai;?></td>
                        <td><?php echo $pesan->keterangan;?></td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>

</body>
</html>