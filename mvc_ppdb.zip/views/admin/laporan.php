<div class="container-fluid">
	<small><a target="blank" href="<?php echo site_url('admin/cetak_laporan');?>" class="btn btn-sm btn-primary"><i class="icon-download"></i> Cetak</a></small>
								<h3 class="header smaller lighter blue">Laporan Peserta yang Lulus Seleksi </h3>
								<table class="table table-striped table-bordered data">
			<thead>
				<tr>			
					<th>No Pendaftaran</th>
					<th>Nama Peserta</th>
					<th>NISN</th>
					<th>Asal Sekolah</th>
					<th>Alamat Tinggal</th>
					<th>Total Nilai</th>
					<th>Status</th>
					<th>Daftar Ulang</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($pesan as $pesan)
				{

				?>
					<tr>
						<td><b><?php echo $pesan->no_pendaftaran."-".$pesan->id_peserta;?></b></td>
						<td><b><?php echo $pesan->nama_lengkap;?></b></td>
						<td><b><?= $pesan->nik; ?></b></td>
						<td><b><?= $pesan->asal_sekolah; ?></b></td>
						<td><b><?= $pesan->alamat_ortu; ?></b></td>
						<td><b><?php echo $pesan->nilai;?></b></td>
						<td><b><?php echo $pesan->keterangan;?></b></td>
						<td><b><?php echo $pesan->daftar_ulang;?></b></td>
					</tr>
				<?php
				
				}
				?>
			</tbody>
		</table>
	</div>