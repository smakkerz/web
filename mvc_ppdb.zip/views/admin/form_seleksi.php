<div class="panel panel-success">
  <div class="panel-heading">
    <h3 class="panel-title">Form Input Nilai Ujian</h3>
  </div>
  <div class="panel-body">
    
<form action="<?php echo site_url('admin/nilai');?>" method="post" class="form-horizontal">
  <div class="form-group">
    <label for="inputEmail3" class="col-sm-3 control-label">No Ujian </label>
    <div class="col-sm-10">
    <select id="state" name="kode" class="form-control" required="required" data-placeholder="Click to Choose...">
                                    <option value="">&nbsp;</option>
                                    <?php 
                          foreach ($seleksi as $key) {
                            echo "<option value='".$key->id_peserta."'>F".$key->no_pendaftaran."-".$key->id_peserta."</option>";
                                    }
                        ?>
                                  </select>
    </div>
  </div>
  <br>
  <div class="form-group">
    <label for="inputPassword3" class="col-sm-3 control-label">Total Nilai Hasil Ujian </label>
    <div class="col-sm-10">
      <input type="number" min="1" max="300" maxlength="3" class="form-control" id="inputPassword3" placeholder="Total Nilai Hasil Ujian(Max. 300)" name="nilai" >
      </div>
      </div>
      <div class="container-fluid">
      <button type="submit" class="btn btn-primary btn-sm">Kirim</button>
    </div>
 </div>
 </form>
 </div>
 </div>