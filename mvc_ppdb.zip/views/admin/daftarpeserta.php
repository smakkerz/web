<div class="container-fluid">
								<h3 class="header smaller lighter blue">Daftar Keseluruhan Peserta : <?php echo $jumlah;?></h3>
								<table class="table table-striped table-responsive data">
			<thead>
				<tr>			
					<th>No Ujian</th>
					<th>NISN</th>
					<th>Nama Peserta</th>
					<th>No Ijazah</th>
					<th>Total Nilai UN</th>
					<th>Asal Sekolah</th>
					<th>Nama Ortu</th>
					<th>Alamat</th>
					<th align="center"><a href="<?php echo site_url('admin/tambahpeserta');?>">Tambah Peserta</a></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ($peserta as $peserta)
				{
				?>
				<tr>
					<td>F<?php echo $peserta->no_pendaftaran."-".$peserta->id_peserta;?></td>
					<td><?php echo $peserta->nik;?></td>
					<td><?php echo $peserta->nama_lengkap;?></td>
					<td><?php echo $peserta->no_ijazah;?></td>
					<td><?php echo $peserta->jumlah_skhun;?></td>
					<td><?php echo $peserta->asal_sekolah;?></td>
					<td><?php echo $peserta->nama_ortu;?></td>
					<td><?php echo $peserta->alamat_ortu;?></td>
					<td><a href="<?php echo site_url('admin/biodatapeserta/'.$peserta->id_peserta);?>">Selengkapnya | </a>
				
					
					</td>
					
				</tr>
				<?php
				}
				?>
			</tbody>
		</table>
	</div>