<?php

class Ppdb_model extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	
	function semua_peserta()
	{
		return $this->db->query("select nama_lengkap, nik, asal_sekolah, no_ijazah, jumlah_skhun, alamat_ortu, keterangan, no_pendaftaran, id_peserta, @rownum:=@rownum+1 rank FROM  peserta, (SELECT @rownum:=0) r ORDER BY jumlah_skhun DESC")->result();
	}

	function semua_jadwal()
	{
		return $this->db->get('jadwal')->result();
	}
	
	function cek_username($username)
	{
		$this->db->select('*');
		$this->db->from('peserta');
		$this->db->where('username',$username);
		
		return $this->db->get()->row();
	}
	
	function daftar_peserta($data)
	{
		$this->db->insert('peserta',$data);
	}
	
	function cek_akun($username,$password)
	{
		$this->db->select('*');
		$this->db->from('peserta');
		$this->db->where('username',$username);
		$this->db->where('password',$password);
		
		return $this->db->get()->row();
	}
	
	function select_by_id($id_peserta)
	{
		$this->db->select('*');
		$this->db->from('peserta');
		$this->db->where('id_peserta',$id_peserta);
		
		return $this->db->get()->row();
	}
	
	function update_biodata($data,$id_peserta)
	{
		$this->db->where('id_peserta',$id_peserta);
		$this->db->update('peserta',$data);
	}

	function pengumuman()
	{
		return $this->db->query("select p.nama_lengkap, p.nik, p.keterangan, s.daftar_ulang, s.id_seleksi, p.asal_sekolah, p.no_pendaftaran, p.id_peserta, s.nilai, @rownum:=@rownum+1 rank FROM `seleksi`s INNER JOIN peserta p ON p.id_peserta = s.id_peserta, (SELECT @rownum:=0) r  WHERE p.keterangan = 'LULUS' ORDER BY s.nilai DESC LIMIT 0,125")->result();
	}

	function kelompok()
	{
		$query = $this->db->query('SELECT COUNT(no_pendaftaran) a, no_pendaftaran FROM `peserta` GROUP BY no_pendaftaran ORDER BY no_pendaftaran desc limit 1');
		$data1 = $query->row();
		$f = $data1->no_pendaftaran;
		$t = explode("-",$f);
		

		if($data1->a > 28){       
   //jika kode ternyata sudah ada.      
   		$data = $t[1] + 1;  
   		$thn = date("Y");
				$id = substr($thn, 2);
   		$kodemax = "0".$data;    
				$daftar = $id."-".$kodemax;
				return $daftar;     
  		} else {           
   		$daftar = $f; 
   			return $daftar;    
  		}
	}
	
	function kirim_pesan($data)
	{
		$this->db->insert('pesan',$data);
	}
	
	function tampilpengumuman()
	{
		$this->db->select('*');
		$this->db->from('pengumuman');
		$this->db->where('id','2');
		
		return $this->db->get()->row();
	}

	function tampiljadwal()
	{
		$this->db->select('*');
		$this->db->from('pengumuman');
		$this->db->where('id','5');
		
		return $this->db->get()->row();
	}

	function jadwalnya($id)
	{
		$this->db->select('*');
		$this->db->from('jadwal');
		$this->db->where('kelompok',$id);
		
		return $this->db->get()->row();
	}

	function tampilkelompok($id)
	{
		$this->db->select('*');
		$this->db->from('peserta');
		$this->db->where('no_pendaftaran',$id);
		
		return $this->db->get()->result();
	}
}