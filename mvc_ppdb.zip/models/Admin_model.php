<?php

class Admin_model extends CI_Model
{
	function __construct()
	{
		parent::__construct();
	}
	
	function daftarpeserta()
	{
		return $this->db->query("SELECT id_peserta, no_pendaftaran FROM peserta wHERE id_peserta NOT IN (SELECT id_peserta FROM seleksi)")->result();
	}

	function daftarpeserta_all()
	{
		return $this->db->get('peserta')->result();
	}

	function daftarjadwal()
	{
		return $this->db->get('jadwal')->result();
	}
	
	function select_by_id($id_peserta)
	{
		$this->db->where('id_peserta',$id_peserta);
		
		return $this->db->get('peserta')->row();
	}
	
	function up_biodata($id_peserta,$data)
	{
		$this->db->where('id_peserta',$id_peserta);
		$this->db->update('peserta',$data);
	}

	function up_seleksi($id_peserta,$data)
	{
		$this->db->where('id_peserta',$id_peserta);
		$this->db->update('seleksi',$data);
	}
	
	function hapus_peserta($id_peserta)
	{
		$this->db->where('id_peserta',$id_peserta);
		$this->db->delete('peserta');
	}
	
	function tambahpeserta($data)
	{
		$this->db->insert('peserta',$data);
	}

	function tambahseleksi($data)
	{
		$this->db->insert('seleksi',$data);
	}

	function tambahjadwal($data)
	{
		$this->db->insert('jadwal',$data);
	}
	
	function pesertabelumdiverifikasi()
	{
		$this->db->select('*');
		$this->db->from('peserta');
		$this->db->where('status','belum diverifikasi');
		
		return $this->db->get()->result();
	}
	
	function pesertatelahverifikasi()
	{
		$this->db->select('*');
		$this->db->from('peserta');
		$this->db->where('status','diverifikasi');
		
		return $this->db->get()->result();
	}
	
	function daftarpesan()
	{
		return $this->db->get('pesan')->result();
	}
	
	function bukapesan($id)
	{
		$this->db->select('*');
		$this->db->from('pesan');
		$this->db->where('id',$id);
		
		return $this->db->get()->row();
	}
	
	function uppesan($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update('pesan',$data);
	}

	function hapuspesan($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('pesan');
	}
	
	function pengumuman()
	{
		$this->db->select('*');
		$this->db->from('pengumuman');
		$this->db->where('id','2');
		
		return $this->db->get()->row();
	}

	function jadwal()
	{
		$this->db->select('*');
		$this->db->from('pengumuman');
		$this->db->where('id','5');
		
		return $this->db->get()->row();
	}
	
	function uppengumuman($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update('pengumuman',$data);
	}
	
	function cek_akun($username,$password)
	{
		$this->db->select('*');
		$this->db->from('admin');
		$this->db->where('username',$username);
		$this->db->where('password',$password);
		
		return $this->db->get()->row();
	}

	function laporan($data)
	{
		return $this->db->select('*')
		->FROM('peserta p')
		->where('p.keterangan',$data)
		->JOIN('seleksi s','s.id_peserta = p.id_peserta', 'INNER')->get()->result();
	}

	function tampilseleksi()
    {
    return $this->db->query("select p.nama_lengkap, p.keterangan, s.daftar_ulang, s.id_seleksi, p.no_pendaftaran, p.id_peserta, s.nilai, @rownum:=@rownum+1 rank FROM `seleksi`s INNER JOIN peserta p ON p.id_peserta = s.id_peserta, (SELECT @rownum:=0) r ORDER BY s.nilai DESC LIMIT 0,125")->result();
    }
    
    function group()
    {
    	return $this->db->query("select no_pendaftaran from peserta where no_pendaftaran NOT IN (select kelompok from jadwal) group by no_pendaftaran")->result();
    }
    function delete_by_id($id)
    {
    	$query = $this->db->delete ('jadwal', "id_jadwal = '$id'");
    	return $query;
    }
 function delete_by_seleksi($id)
    {
    	$query = $this->db->delete ('seleksi', "id_seleksi = '$id'");
    	return $query;
    }   
}